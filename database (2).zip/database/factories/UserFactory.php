<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\User>
 */
class UserFactory extends Factory
{
    /**
     * The current password being used by the factory.
     */
    protected static ?string $password;

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'name' => fake()->name(),
            'email' => fake()->unique()->safeEmail(),
            'email_verified_at' => now(),
            'password' => static::$password ??= Hash::make('password'),
            'remember_token' => Str::random(10),
            'date_of_birth' => fake()->dateTimeBetween('-65 years', '-18 years')->format('Y-m-d'),
            'phone' => fake()->phoneNumber(),
            // Create the related rows rather than assuming a seeder has run:
            // hardcoded ids fail the foreign keys on a fresh database.
            'region_id' => \App\Models\Region::firstOrCreate(
                ['name' => 'Cairo'],
                ['code' => 'CAI']
            )->id,
            'role_id' => \App\Models\Role::firstOrCreate(
                ['name' => 'CLIENT'],
                ['description' => 'Standard customer account']
            )->id,
        ];
    }

    /**
     * Indicate that the model's email address should be unverified.
     */
    public function unverified(): static
    {
        return $this->state(fn (array $attributes) => [
            'email_verified_at' => null,
        ]);
    }

    /**
     * Create an admin user
     */
    public function admin(): static
    {
        return $this->state(fn (array $attributes) => [
            'role_id' => \App\Models\Role::firstOrCreate(
                ['name' => 'ADMIN'],
                ['description' => 'Store administrator']
            )->id,
        ]);
    }

    /**
     * Create a client user
     */
    public function client(): static
    {
        return $this->state(fn (array $attributes) => [
            'role_id' => \App\Models\Role::firstOrCreate(
                ['name' => 'CLIENT'],
                ['description' => 'Standard customer account']
            )->id,
        ]);
    }
}
