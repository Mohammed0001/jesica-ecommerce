<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained();
            $table->decimal('amount', 10, 2);
            $table->string('method'); // credit_card, paypal, bank_transfer
            $table->string('provider')->default('mock'); // mock, stripe, paypal
            $table->string('provider_transaction_id')->nullable();
            $table->enum('status', ['pending', 'succeeded', 'failed', 'cancelled'])->default('pending');
            $table->string('type')->default('payment'); // payment, deposit, remaining
            $table->json('meta')->nullable(); // Additional payment details
            $table->timestamps();

            $table->index(['order_id', 'type']);
            $table->index('status');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('payments');
    }
};
